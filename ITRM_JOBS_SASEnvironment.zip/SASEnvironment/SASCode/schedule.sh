#!/bin/bash 
#
# schedule.sh
#
# syslog      Schedule AutoLoad.sas
#

RUNSAS_PATH="/sas/sas94/config/Lev1/SASApp/SASEnvironment/SASCode/VMware_Daily_Overall.sh"
MINUTE_TO_START=01
HOUR_TO_START=00
DAY_TO_START=*
MONTH_TO_START=*
WEEKDAY_TO_START=*




#call to runsas.sh
cat <(fgrep -i -v $RUNSAS_PATH <(crontab -l)) <(echo "*/$MINUTE_TO_START $HOUR_TO_START * * * $RUNSAS_PATH > /dev/null ") | crontab -

