export ADAPTER=VMWare_Daily
export BASE=/sas/sas94/config/Lev1/SASApp/SASEnvironment 
export LOGDIR=$BASE/Logs
export JOBDIR=$BASE/SASCode/Jobs
export SRC=VMware_Daily_Overall
export DATETIME=$(date +"%Y%m%d_%H%M")
SAS=/sas/sas94/config/Lev1/SASApp/sas.sh
$SAS �sysin $BASE/SASCode/$SRC.sas -log $LOGDIR/"$SRC"_"$DATETIME".log -noterminal -rsasuser &
