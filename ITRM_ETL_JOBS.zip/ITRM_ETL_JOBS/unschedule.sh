#!/bin/bash 
#
# unschedule.sh
#
# syslog      Unschedule AutoLoad.sas
#

RUNSAS_PATH="/sas/sas94/config/Lev1/SASApp/SASEnvironment/SASCode/VMware_Daily_Overall.sh"

crontab -l|fgrep -i -v $RUNSAS_PATH|crontab

