export ADAPTER=SMF_Weekly
export BASE=/sas/sas94/config/Lev1/SASApp/SASEnvironment 
export LOGDIR=$BASE/Logs
export JOBDIR=$BASE/SASCode/Jobs
export SRC=SMF_Weekly_Reporting
export DATETIME=$(date +"%Y%m%d_%H%M")
SAS=/sas/sas94/config/Lev1/SASApp/sas.sh
$SAS �sysin $BASE/SASCode/$SRC.sas -log $LOGDIR/"$SRC"_"$DATETIME".log -noterminal -rsasuser &